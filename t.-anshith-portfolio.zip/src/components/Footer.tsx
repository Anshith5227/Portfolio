export default function Footer() {
  return (
    <footer className="py-8 px-6 text-center border-t border-white/5 relative z-10 bg-zinc-950">
      <div className="max-w-7xl mx-auto flex flex-col items-center justify-center space-y-2">
        <p className="text-zinc-300 font-medium text-lg">
          T. Anshith
        </p>
        <p className="text-zinc-500 text-sm">
          B.Tech CSE Student &bull; CMR College of Engineering and Technology
        </p>
        <p className="text-zinc-600 text-xs mt-4">
          &copy; {new Date().getFullYear()} T. Anshith. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
