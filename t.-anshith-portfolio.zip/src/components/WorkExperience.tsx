import { motion } from 'motion/react';
import { Sparkles, Megaphone, Users, Award } from 'lucide-react';

export default function WorkExperience() {
  return (
    <section id="work" className="py-24 px-6 md:px-12 relative">
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-orange-500/5 blur-[120px] rounded-full pointer-events-none -translate-x-1/2 -translate-y-1/2" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-16 md:mb-24"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Work & Experience<span className="text-orange-500">.</span>
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mb-6">
            Experiences, events, hackathons and activities that shaped my skills.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-orange-500 to-transparent rounded-full" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Hackathons - Large Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="md:col-span-2 lg:col-span-2 row-span-2 group cursor-pointer"
          >
            <div className="h-full bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-3xl p-6 lg:p-8 flex flex-col transition-all duration-500 hover:bg-zinc-900/70 hover:border-orange-500/30 hover:shadow-[0_20px_40px_rgba(0,0,0,0.4)] hover:-translate-y-1">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 rounded-2xl bg-orange-500/10 text-orange-400 border border-orange-500/20">
                  <Award size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Hackathons</h3>
                  <p className="text-zinc-400">Competitive Programming</p>
                </div>
              </div>
              <p className="text-zinc-300 mb-8 text-lg">
                Participated in multiple hackathons, collaborating with teams to build innovative solutions under time constraints.
              </p>
              
              <div className="mt-auto relative rounded-2xl overflow-hidden border border-white/10 bg-zinc-950 aspect-[16/9] sm:aspect-auto sm:h-64 flex items-center justify-center">
                <div className="absolute inset-0 bg-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10" />
                <img
                  src="/25H51A05CW-1.png"
                  alt="Hackathon Certificate"
                  className="w-full h-full object-contain p-2 transform transition-transform duration-700 group-hover:scale-105"
                />
              </div>
            </div>
          </motion.div>

          {/* Student Council */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="group"
          >
            <div className="h-full bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-3xl p-6 lg:p-8 flex flex-col transition-all duration-500 hover:bg-zinc-900/70 hover:border-orange-500/30 hover:shadow-[0_15px_30px_rgba(0,0,0,0.3)] hover:-translate-y-1">
              <div className="p-3 w-fit rounded-2xl bg-zinc-800 text-zinc-300 border border-white/5 mb-6 group-hover:bg-orange-500/10 group-hover:text-orange-400 group-hover:border-orange-500/20 transition-colors">
                <Megaphone size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-50 transition-colors">
                Student Council
              </h3>
              <p className="text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                Part of Student Council — I&E CMR. Active involvement in leadership, representation, and institutional activities.
              </p>
            </div>
          </motion.div>

          {/* Street Cause */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="group"
          >
            <div className="h-full bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-3xl p-6 lg:p-8 flex flex-col transition-all duration-500 hover:bg-zinc-900/70 hover:border-orange-500/30 hover:shadow-[0_15px_30px_rgba(0,0,0,0.3)] hover:-translate-y-1">
              <div className="p-3 w-fit rounded-2xl bg-zinc-800 text-zinc-300 border border-white/5 mb-6 group-hover:bg-orange-500/10 group-hover:text-orange-400 group-hover:border-orange-500/20 transition-colors">
                <Users size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-50 transition-colors">
                Street Cause Hyderabad
              </h3>
              <p className="text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                Worked for Street Cause Hyderabad and worked with multiple NGOs for one year, dedicating time to social and community service.
              </p>
            </div>
          </motion.div>

          {/* CMR Events */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="md:col-span-2 lg:col-span-1 group"
          >
            <div className="h-full bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-3xl p-6 lg:p-8 flex flex-col transition-all duration-500 hover:bg-zinc-900/70 hover:border-orange-500/30 hover:shadow-[0_15px_30px_rgba(0,0,0,0.3)] hover:-translate-y-1">
              <div className="p-3 w-fit rounded-2xl bg-zinc-800 text-zinc-300 border border-white/5 mb-6 group-hover:bg-orange-500/10 group-hover:text-orange-400 group-hover:border-orange-500/20 transition-colors">
                <Sparkles size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-50 transition-colors">
                Event Organization
              </h3>
              <p className="text-zinc-400 leading-relaxed group-hover:text-zinc-300 transition-colors">
                Helped in organizing multiple events at CMR College of Engineering and Technology, demonstrating strong event coordination, teamwork, and crowd handling capabilities.
              </p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
