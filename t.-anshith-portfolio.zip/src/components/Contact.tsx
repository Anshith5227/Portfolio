import { motion } from 'motion/react';
import { Mail, Linkedin, ArrowUpRight } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 px-6 md:px-12 relative overflow-hidden">
      {/* Background radial gradient */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-[800px] h-[800px] bg-orange-500/5 blur-[150px] rounded-full pointer-events-none" />
      
      <div className="max-w-4xl mx-auto relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-12"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Let's Connect<span className="text-orange-500">.</span>
          </h2>
          <p className="text-zinc-400 text-lg md:text-xl max-w-2xl mx-auto">
            Have an opportunity, project, or idea? Feel free to get in touch.
          </p>
        </motion.div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <motion.a
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            href="mailto:anshith0123@gmail.com"
            className="group w-full sm:w-auto flex items-center gap-4 bg-zinc-900/60 backdrop-blur-xl border border-white/10 px-8 py-5 rounded-2xl transition-all duration-300 hover:bg-zinc-800/80 hover:border-orange-500/50 hover:shadow-[0_10px_30px_rgba(249,115,22,0.15)] hover:-translate-y-1"
          >
            <div className="p-2 rounded-full bg-zinc-800 text-zinc-300 group-hover:bg-orange-500/20 group-hover:text-orange-400 transition-colors">
              <Mail size={24} />
            </div>
            <div className="text-left">
              <div className="text-xs text-zinc-500 uppercase tracking-wider font-semibold mb-1">Email</div>
              <div className="text-white font-medium text-lg">anshith0123@gmail.com</div>
            </div>
            <ArrowUpRight size={20} className="ml-4 text-zinc-600 group-hover:text-orange-400 transition-colors opacity-0 group-hover:opacity-100 -translate-x-2 translate-y-2 group-hover:translate-x-0 group-hover:translate-y-0 duration-300" />
          </motion.a>

          <motion.a
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            href="https://www.linkedin.com/in/anshith-t-01709b36a/"
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full sm:w-auto flex items-center gap-4 bg-zinc-900/60 backdrop-blur-xl border border-white/10 px-8 py-5 rounded-2xl transition-all duration-300 hover:bg-zinc-800/80 hover:border-orange-500/50 hover:shadow-[0_10px_30px_rgba(249,115,22,0.15)] hover:-translate-y-1"
          >
            <div className="p-2 rounded-full bg-zinc-800 text-zinc-300 group-hover:bg-[#0A66C2]/20 group-hover:text-[#0A66C2] transition-colors">
              <Linkedin size={24} />
            </div>
            <div className="text-left">
              <div className="text-xs text-zinc-500 uppercase tracking-wider font-semibold mb-1">LinkedIn</div>
              <div className="text-white font-medium text-lg">T. Anshith</div>
            </div>
            <ArrowUpRight size={20} className="ml-4 text-zinc-600 group-hover:text-[#0A66C2] transition-colors opacity-0 group-hover:opacity-100 -translate-x-2 translate-y-2 group-hover:translate-x-0 group-hover:translate-y-0 duration-300" />
          </motion.a>
        </div>
      </div>
    </section>
  );
}
