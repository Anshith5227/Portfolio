import { motion } from 'motion/react';
import { Users, Mic, Trophy, Target } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: <Users size={20} />,
      title: 'Student Council',
      description: 'Part of Student Council — I&E CMR',
    },
    {
      icon: <Mic size={20} />,
      title: 'Communication',
      description: 'Effective Communicator',
    },
    {
      icon: <Trophy size={20} />,
      title: 'Hackathons & Events',
      description: 'Participated in multiple hackathons and skill development events',
    },
    {
      icon: <Target size={20} />,
      title: 'Leadership',
      description: 'Can effectively handle large crowds and teams',
    },
  ];

  return (
    <section id="about" className="py-24 px-6 md:px-12 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/4 -right-1/4 w-96 h-96 bg-orange-500/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-16 md:mb-24"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            About Me<span className="text-orange-500">.</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-orange-500 to-transparent rounded-full" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Image & Certificate */}
          <div className="lg:col-span-5 space-y-12">
            {/* Smaller Portrait */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="relative w-3/4 mx-auto lg:mx-0 lg:w-full max-w-sm"
            >
              <div className="absolute -inset-4 bg-gradient-to-tr from-orange-500/10 to-transparent blur-2xl rounded-full opacity-50" />
              
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-zinc-900/60 backdrop-blur-md border border-white/10 p-2 shadow-xl">
                <div className="w-full h-full rounded-xl overflow-hidden relative">
                  <img
                    src="/biga.png"
                    alt="T. Anshith Portrait"
                    className="w-full h-full object-cover object-top opacity-90"
                  />
                  <div className="absolute inset-0 bg-zinc-900/10 mix-blend-overlay" />
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -left-6 top-1/2 w-12 h-[1px] bg-orange-500/40" />
              <div className="absolute -bottom-6 -right-4 w-24 h-24 bg-zinc-800/40 backdrop-blur-md rounded-xl border border-white/5 -z-10 rotate-12" />
            </motion.div>

            {/* Certificate */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="group relative cursor-pointer"
            >
              <div className="absolute -inset-2 bg-orange-500/20 blur-xl rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative rounded-xl overflow-hidden bg-zinc-900/80 backdrop-blur-xl border border-white/10 p-2 shadow-lg transition-all duration-500 group-hover:scale-[1.05] group-hover:-translate-y-2 group-hover:shadow-[0_20px_40px_rgba(0,0,0,0.4)] group-hover:border-orange-500/30">
                <div className="w-full h-auto rounded-lg overflow-hidden bg-zinc-950">
                  <img
                    src="/klshawfdh.png" 
                    alt="Hackathon Certificate"
                    className="w-full h-auto object-contain opacity-80 group-hover:opacity-100 transition-opacity duration-500"
                  />
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                   <div className="bg-zinc-950/80 text-white text-sm px-4 py-2 rounded-full border border-white/10 backdrop-blur-md">
                     View Achievement
                   </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Content */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-zinc-300 text-lg leading-relaxed mb-4"
            >
              As a dedicated Computer Science student, I blend technical programming knowledge with strong interpersonal and leadership skills. I thrive in dynamic environments where problem-solving and collaboration intersect.
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
                  className="bg-zinc-900/30 backdrop-blur-sm border border-white/5 rounded-2xl p-6 group hover:bg-zinc-900/60 hover:border-orange-500/20 transition-all duration-300"
                >
                  <div className="w-12 h-12 rounded-full bg-zinc-800/80 flex items-center justify-center text-orange-500 mb-4 border border-white/5 group-hover:bg-orange-500/10 group-hover:border-orange-500/30 transition-colors">
                    {feature.icon}
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-zinc-400 text-sm leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
