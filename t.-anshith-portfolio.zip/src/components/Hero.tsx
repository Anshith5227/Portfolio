import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] },
    },
  };

  const scrollToAbout = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center pt-24 pb-12 px-6 md:px-12 relative">
      <div className="max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        
        {/* Left Column: Image */}
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
          className="relative order-2 lg:order-1 flex justify-center lg:justify-start"
        >
          <div className="relative group w-full max-w-md">
            {/* Background ambient glow */}
            <div className="absolute inset-0 bg-orange-500/20 blur-[80px] rounded-full mix-blend-screen opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
            
            {/* Image Container */}
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-zinc-900/40 backdrop-blur-sm border border-white/10 p-2 shadow-2xl transition-transform duration-500 ease-out group-hover:scale-[1.03]">
              <div className="w-full h-full rounded-xl overflow-hidden relative bg-zinc-800">
                <img
                  src="/biga.png"
                  alt="T. Anshith"
                  className="w-full h-full object-cover object-top opacity-90 transition-opacity duration-500 group-hover:opacity-100"
                />
                {/* Subtle glass overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 via-transparent to-transparent opacity-60" />
              </div>
            </div>
            
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-orange-500/10 backdrop-blur-xl rounded-full border border-orange-500/20 -z-10 transition-transform duration-700 group-hover:translate-x-2 group-hover:-translate-y-2" />
          </div>
        </motion.div>

        {/* Right Column: Text content */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="order-1 lg:order-2 flex flex-col justify-center text-center lg:text-left"
        >
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-sm font-medium w-fit mx-auto lg:mx-0 mb-6">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
            Portfolio
          </motion.div>
          
          <motion.h1 variants={itemVariants} className="text-5xl md:text-6xl lg:text-7xl font-bold text-white tracking-tight leading-tight mb-4">
            T. Anshith<span className="text-orange-500">.</span>
          </motion.h1>
          
          <motion.h2 variants={itemVariants} className="text-xl md:text-2xl text-zinc-300 font-medium mb-2">
            B.Tech CSE Student
          </motion.h2>
          
          <motion.p variants={itemVariants} className="text-lg md:text-xl text-zinc-400 mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
            CMR College of Engineering and Technology
            <br />
            Currently pursuing B.Tech in Computer Science and Engineering &mdash; 2nd Year
          </motion.p>
          
          <motion.div variants={itemVariants} className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto lg:mx-0">
            <div className="bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-xl p-4 flex flex-col items-center sm:items-start transition-colors hover:bg-zinc-900/60 hover:border-white/10">
              <span className="text-zinc-500 text-sm font-medium mb-1">Focus</span>
              <span className="text-zinc-200 font-medium">Computer Science</span>
            </div>
            <div className="bg-zinc-900/40 backdrop-blur-md border border-white/5 rounded-xl p-4 flex flex-col items-center sm:items-start transition-colors hover:bg-zinc-900/60 hover:border-white/10">
              <span className="text-zinc-500 text-sm font-medium mb-1">Current Year</span>
              <span className="text-zinc-200 font-medium">2nd Year</span>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.a
        href="#about"
        onClick={scrollToAbout}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-zinc-500 hover:text-orange-400 transition-colors group"
      >
        <span className="text-xs uppercase tracking-widest font-medium">Scroll to explore</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          className="p-2 rounded-full bg-zinc-900/50 border border-white/5 group-hover:border-orange-500/30 transition-colors"
        >
          <ArrowDown size={16} />
        </motion.div>
      </motion.a>
    </section>
  );
}
