import { motion } from 'motion/react';
import { Code2, Database, Users, MessageSquare } from 'lucide-react';

const skills = [
  {
    id: '01',
    title: 'Programming',
    description: 'Proficient in Python, C, and Java',
    icon: <Code2 size={24} />,
  },
  {
    id: '02',
    title: 'Data Structures',
    description: 'Proficiency in Data Structures and Management',
    icon: <Database size={24} />,
  },
  {
    id: '03',
    title: 'Event & Crowd Management',
    description: 'Experience managing large crowds and public events',
    icon: <Users size={24} />,
  },
  {
    id: '04',
    title: 'Communication',
    description: 'Effective Communicator',
    icon: <MessageSquare size={24} />,
  },
];

export default function SkillsTimeline() {
  return (
    <section id="skills" className="py-24 px-6 md:px-12 relative">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-20 text-center md:text-left"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Skills<span className="text-orange-500">.</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-orange-500 to-transparent rounded-full mx-auto md:mx-0" />
        </motion.div>

        <div className="relative">
          {/* Vertical Line */}
          <motion.div
            initial={{ height: 0 }}
            whileInView={{ height: '100%' }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute left-[28px] md:left-1/2 top-0 bottom-0 w-[2px] bg-gradient-to-b from-orange-500/50 via-zinc-800 to-transparent md:-translate-x-1/2"
          />

          <div className="space-y-12 md:space-y-24">
            {skills.map((skill, index) => {
              const isEven = index % 2 === 0;

              return (
                <div key={skill.id} className="relative flex items-center md:justify-between w-full">
                  {/* Timeline Node */}
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="absolute left-[29px] md:left-1/2 w-4 h-4 rounded-full bg-zinc-950 border-2 border-orange-500 -translate-x-1/2 z-10 shadow-[0_0_15px_rgba(249,115,22,0.5)] transition-all duration-300 hover:scale-125"
                  />

                  {/* Card Container */}
                  <div className={`w-full flex ${isEven ? 'md:justify-start' : 'md:justify-end'} pl-16 md:pl-0`}>
                    <motion.div
                      initial={{ opacity: 0, x: isEven ? -30 : 30, y: 20 }}
                      whileInView={{ opacity: 1, x: 0, y: 0 }}
                      viewport={{ once: true, margin: "-50px" }}
                      transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                      className={`w-full md:w-[42%] group`}
                    >
                      <div className="bg-zinc-900/40 backdrop-blur-md border border-white/5 p-6 rounded-2xl shadow-xl transition-all duration-400 ease-out hover:-translate-y-2 hover:bg-zinc-900/70 hover:border-orange-500/30 hover:shadow-[0_20px_40px_rgba(0,0,0,0.3)]">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="text-orange-500/80 font-mono text-xl font-bold opacity-50 group-hover:opacity-100 transition-opacity">
                            {skill.id}
                          </div>
                          <div className="p-2.5 rounded-xl bg-zinc-800/80 border border-white/5 text-zinc-300 group-hover:text-orange-400 group-hover:bg-orange-500/10 transition-colors">
                            {skill.icon}
                          </div>
                        </div>
                        <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-orange-50 transition-colors">
                          {skill.title}
                        </h3>
                        <p className="text-zinc-400 text-sm leading-relaxed group-hover:text-zinc-300 transition-colors">
                          {skill.description}
                        </p>
                      </div>
                    </motion.div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
