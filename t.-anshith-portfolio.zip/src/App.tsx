/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import SkillsTimeline from './components/SkillsTimeline';
import WorkExperience from './components/WorkExperience';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CursorGlow from './components/CursorGlow';

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-orange-500/30 selection:text-orange-200 overflow-x-hidden">
      <CursorGlow />
      <Navbar />
      
      <main className="relative z-10">
        <Hero />
        <About />
        <SkillsTimeline />
        <WorkExperience />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
